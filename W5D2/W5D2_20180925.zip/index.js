var response = {
  shirts: [{
    title: 'Swoosh T-Shirt',
    availableSizes: ['small', 'medium', 'large'],
    materials: {
      cotton: 98,
      rayon: 1,
      lycra: 1
    },
    graphic: 'https://upload.wikimedia.org/wikipedia/commons/a/a6/Logo_NIKE.svg',
    inStock: true
  },
  {
    title: 'Baseball T-Shirt',
    availableSizes: ['small', 'medium', 'large', 'x-large'],
    materials: {
      cotton: 60,
      polyester: 40
    },
    graphic: 'https://upload.wikimedia.org/wikipedia/commons/9/92/Baseball.svg',
    inStock: false
  }]
}

$(document).ready(function() {
  
  function showResults(event) {
    event.preventDefault();
    $(this).slideUp();
    response.shirts.forEach(function(shirt) {
      $('<div>')
        .append('<img src="' + shirt.graphic + '" />')
        .append('<h2>' + shirt.title + '</h2>')
        .append('<p class="shirt-sizes">Available Sizes: ' + shirt.availableSizes.join(', ') + '</p>')
        .appendTo('.results')
    })
  }

  $('form').on('submit', showResults);
});