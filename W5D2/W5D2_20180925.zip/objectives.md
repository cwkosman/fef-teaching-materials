#### BTEOTLYWBAT:
    - access and loop over nested data from within a mock response object
    - manipulate elements on your page with jQuery methods
    - create displays of similar data by combining these two actions
