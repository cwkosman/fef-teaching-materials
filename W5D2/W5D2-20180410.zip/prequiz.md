#### But first:
    - What symbol do I use to access jQuery methods?
    - What is the name for something I attach to an HTML element to
      determine when a user has interacted with it?
    - Name two data structures in Javascript.
