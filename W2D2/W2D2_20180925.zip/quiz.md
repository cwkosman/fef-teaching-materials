##### Write out the HTML that each of these CSS selectors would target:

- article

- p.article

- #article

- div .article

- .article

##### Rank the selectors in order of specificity.

