#### BTEOTLYWBAT:
    - capture user input
    - retrieve data from a remote source
    - use jQuery to accept more user input
