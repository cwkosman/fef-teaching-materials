##### BTEOTLYWBAT:
 - compose CSS **selectors** and identify their **specificity**
 - link a stylesheet to an HTML document
 - determine why an element would receive one style over another
 - write CSS **rules** with some common **properties** and **values**
