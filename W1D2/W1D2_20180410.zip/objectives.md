##### By the end of this lesson, you will be able to (BTEOTLYWBAT):

  - translate a wirefame into a basic HTML document using a code editor

  - use semantic tags and explain why they are preferable over a non-semantic tags

  - demonstrate consistent indentation and explain why this is important to developers
