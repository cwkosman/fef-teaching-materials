##### BTEOTLYSBAT:

- Style states of an element with pseudo-classes
- Style parts of an element with pseudo-elements
- Write a basic CSS transition