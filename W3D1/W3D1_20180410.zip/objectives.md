##### BTEOTLYSBAT:

- Style states of an element with pseudoclasses
- Style parts of an element with pseudoelements
- Write a basic CSS transition