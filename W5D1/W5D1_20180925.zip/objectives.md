##### BTEOTLYWBAT:
- Solve left over W4D2 problems
- Use jQuery to manipulate elements on a page
- Perform common jQuery tasks, including: 
    - Selecting elements on a page
    - Adding event listeners
    - Adding and removing CSS classes
    - Executing simple animations
