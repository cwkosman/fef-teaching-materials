jQuery(document).ready(function() {
  var h1 = jQuery('h1');
  console.log(h1);

  var h2 = jQuery('h2');
  console.log(h2);

  var subtitle = jQuery('.subtitle');
  console.log(subtitle);

  h1.on('click', function() {
    alert('Catsssssss');
  })

  h1.on('mouseenter', function() {
    console.log('Entering the danger zone');
  });

  h1.on('mouseleave', function() {
    console.log('Leaving the danger zone');
  })

  h1.on('mouseenter', function() {
    jQuery(this).addClass('container');
  })

  h1.on('mouseleave', function() {
    jQuery(this).removeClass('container');
  })

  h1.on('mouseenter', function() {
    // jQuery('body').css('background-color', 'green');
    jQuery(this).fadeOut(10000);
  })

  jQuery('form').on('submit', function(event) {
    event.preventDefault();
    jQuery(this).delay(1000).slideUp(1000);
  })
});
