# front-end-fundamentals-js-starter-files
Starter files for the jQuery project for the front end fundamentals pilot
