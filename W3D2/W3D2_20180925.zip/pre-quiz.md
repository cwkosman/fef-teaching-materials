Your boss has asked this button:

 - https://codepen.io/cwkosman/pen/wyBbYg

interact to user input. It should be coloured purple on hover AND that hover state should not be instantaneous.
