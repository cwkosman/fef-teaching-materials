#### BTEOTLYSBAT:

- Use media queries and CSS properties to make your page responsive
- Deploy your resume
